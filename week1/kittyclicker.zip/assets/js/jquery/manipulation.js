function manipulation() {

}